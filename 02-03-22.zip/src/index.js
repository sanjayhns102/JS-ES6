import "./styles.css";

document.getElementById("app").innerHTML = `
<h1>JavaScript ES6</h1>
<div>
  We use the online Editor...
</div>
`;

////////////// Core Javascript /////////////

// Variables?
// Variables are containers for storing data (storing data values).
// In this example, x, y, and z, are variables, declared with the var keyword:
// x = 5;
// y = 6;
// z = x + y;

// ////////////// Advance Javascript /////////////
// ************* JavaScript Let **************
// The let keyword was introduced in ES6 (2015).

// Variables defined with let cannot be Redeclared.

// Variables defined with let must be Declared before use.

// Variables defined with let have Block Scope

// *********** Cannot be Redeclared *********
// Variables defined with let cannot be redeclared.

// We cannot accidentally redeclare a variable.

// With let We can not do this:

// Example
// let x = "John Doe";

// let x = 0;
//  SyntaxError: 'x' has already been declared

// Block Scope
// Before ES6 (2015), JavaScript had only Global Scope and Function Scope.

// ES6 introduced two important new JavaScript keywords: let and const.

// These two keywords provide Block Scope in JavaScript.

// Variables declared inside a { } block cannot be accessed from outside the block:

// Example
// {
//   let x = 2;
// }
// x can NOT be used here
// Variables declared with the var keyword can NOT have block scope.

// Variables declared inside a { } block can be accessed from outside the block.

// Example
// {
//   var x = 2;
// }
// x CAN be used here

/////////////// JavaScript Const  ///////////////
// The const keyword was introduced in ES6 (2015).

// Variables defined with const cannot be Redeclared.

// Variables defined with const cannot be Reassigned.

// Variables defined with const have Block Scope.

// Cannot be Reassigned
// A const variable cannot be reassigned:

// Example
// const PI = 3.141592653589793;
// PI = 3.14;      // This will give an error
// PI = PI + 10;   // This will also give an error
// Must be Assigned
// JavaScript const variables must be assigned a value when they are declared:

// Correct
// const PI = 3.14159265359;
// Incorrect
// const PI;
// PI = 3.14159265359;
// When to use JavaScript const?
// As a general rule, always declare a variable with const unless We know that the value will change.

// Use const when We declare:

// A new Array
// A new Object
// A new Function
// A new RegExp
// Constant Objects and Arrays
// The keyword const is a little misleading.

// It does not define a constant value. It defines a constant reference to a value.

// Because of this We can NOT:
// Reassign a constant value
// Reassign a constant array
// Reassign a constant object
// But We CAN:

// Change the elements of constant array
// Change the properties of constant object
// Constant Arrays
// We can change the elements of a constant array:
// Example
// // We can create a constant array:
// const cars = ["Saab", "Volvo", "BMW"];
// // We can change an element:
// cars[0] = "Toyota";
// // We can add an element:
// cars.push("Audi");

// But We can NOT reassign the array:
// Example
// const cars = ["Saab", "Volvo", "BMW"];
// cars = ["Toyota", "Volvo", "Audi"];    // ERROR

// Constant Objects
// We can change the properties of a constant object:
// Example
// // We can create a const object:
// const car = {type:"Fiat", model:"500", color:"white"};
// // We can change a property:
// car.color = "red";
// // We can add a property:
// car.owner = "Johnson";

// But We can NOT reassign the object:
// Example
// const car = {type:"Fiat", model:"500", color:"white"};
// car = {type:"Volvo", model:"EX60", color:"red"};    // ERROR

///////////// Arrow Functions //////////////
// Arrow functions allows a short syntax for writing function expressions.
// You don't need the function keyword, the return keyword, and the curly brackets.
// Example
// // ES5
// var x = function(x, y) {
//    return x * y;
// }

// // ES6
// const x = (x, y) => x * y;

// ************ Drwabacks ***********
// Arrow functions do not have their own this. They are not well suited for defining object methods.
// Arrow functions are not hoisted. They must be defined before they are used.
// Using const is safer than using var, because a function expression is always a constant value.
// You can only omit the return keyword and the curly brackets if the function is a single statement. Because of this, it might be a good habit to always keep them:
// Example
// const x = (x, y) => { return x * y };

// *** Arrow Functions Return Value by Default: ****
// hello = () => "Hello World!";

// If you have parameters, you pass them inside the parentheses:
// Arrow Function With Parameters:
// hello = (val) => "Hello " + val;
